<?php
  // DB Params
  define('DB_HOST', 'mysql.inscripchat.com');
  define('DB_USER', 'mkwepile');
  define('DB_PASS', 'C00CHIE@100%');
  define('DB_NAME', 'inscripchat');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'https://www.inscripchat.com');
  // Site Name
  define('SITENAME', 'Inscripchat');

  // PHPMailer
  define("SMTP_HOST", "smtp.dreamhost.com");
  define("SMTP_PORT", "465");
  define("SMTP_USERNAME", "support@inscripchat.com");
  define("SMTP_PASSWORD", "sqesUB4?");
  define("SMTP_NAME", "Inscripchat");