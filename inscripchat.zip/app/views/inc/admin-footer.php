<div class="overlay"></div>
</div>
</div>

<script src="<?php echo URLROOT; ?>/public/admin-assets/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.6.0/umd/popper.min.js" integrity="sha512-BmM0/BQlqh02wuK5Gz9yrbe7VyIVwOzD1o40yi1IsTjriX/NGF37NyXHfmFzIlMmoSIBXgqDiG1VNU6kB5dBbA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>

<script src="<?php echo URLROOT; ?>/public/admin-assets/js/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="<?php echo URLROOT; ?>/public/admin-assets/js/layout.js"></script>
<script src="<?php echo URLROOT; ?>/public/admin-assets/js/app.js"></script>

<script>
    $(".menu-item a").each(function() {
        
    })
</script>

</body>

</html>