<div class="emoji-dashboard">
    <ul class="emojis">
        <!-- Smile Emojis -->
        <li class="emoji" data-emoji="1f604"><i class="em em-smile"></i></li>
        <li class="emoji" data-emoji="1f603"><i class="em em-grinning"></i></li>
        <li class="emoji" data-emoji="1f601"><i class="em em-grin"></i></li>
        <li class="emoji" data-emoji="1f602"><i class="em em-joy"></i></li>
        <li class="emoji" data-emoji="1f642"><i class="em em-slightly_smiling_face"></i></li>
        <li class="emoji" data-emoji="1f60a"><i class="em em-smiley"></i></li>
        <li class="emoji" data-emoji="1f60f"><i class="em em-smirk"></i></li>
        <li class="emoji" data-emoji="1f606"><i class="em em-laughing"></i></li>
        <li class="emoji" data-emoji="1f644"><i class="em em-face_with_rolling_eyes"></i></li>
        <li class="emoji" data-emoji="1f60d"><i class="em em-heart_eyes"></i></li>

        <!-- Sad Emojis -->
        <li class="emoji" data-emoji="1f62d"><i class="em em-sob"></i></li>
        <li class="emoji" data-emoji="1f622"><i class="em em-cry"></i></li>
        <li class="emoji" data-emoji="1f61e"><i class="em em-disappointed"></i></li>
        <li class="emoji" data-emoji="1f614"><i class="em em-pensive"></i></li>
        <li class="emoji" data-emoji="1f629"><i class="em em-weary"></i></li>
        <li class="emoji" data-emoji="1f616"><i class="em em-confounded"></i></li>
        <li class="emoji" data-emoji="1f62b"><i class="em em-tired_face"></i></li>
        <li class="emoji" data-emoji="1f620"><i class="em em-angry"></i></li>
        <li class="emoji" data-emoji="1f631"><i class="em em-scream"></i></li>
        <li class="emoji" data-emoji="1f47f"><i class="em em-imp"></i></li>

        <!-- Love Emojis -->
        <li class="emoji" data-emoji="2764"><i class="em em-heart"></i></li>
        <li class="emoji" data-emoji="1f494"><i class="em em-broken_heart"></i></li>
        <li class="emoji" data-emoji="1f48b"><i class="em em-kissing_heart"></i></li>
        <li class="emoji" data-emoji="1f48c"><i class="em em-love_letter"></i></li>
        <li class="emoji" data-emoji="1f496"><i class="em em-sparkling_heart"></i></li>
        <li class="emoji" data-emoji="1f495"><i class="em em-two_hearts"></i></li>
        <li class="emoji" data-emoji="1f49e"><i class="em em-revolving_hearts"></i></li>
        <li class="emoji" data-emoji="1f493"><i class="em em-heartbeat"></i></li>
        <li class="emoji" data-emoji="1f498"><i class="em em-cupid"></i></li>
        <li class="emoji" data-emoji="1f497"><i class="em em-heartpulse"></i></li>

        <!-- Food Emojis -->
        <li class="emoji" data-emoji="1f355"><i class="em em-pizza"></i></li>
        <li class="emoji" data-emoji="1f354"><i class="em em-hamburger"></i></li>
        <li class="emoji" data-emoji="1f369"><i class="em em-doughnut"></i></li>
        <li class="emoji" data-emoji="1f366"><i class="em em-ice_cream"></i></li>
        <li class="emoji" data-emoji="1f353"><i class="em em-strawberry"></i></li>
        <li class="emoji" data-emoji="1f32e"><i class="em em-taco"></i></li>
        <li class="emoji" data-emoji="1f363"><i class="em em-sushi"></i></li>
        <li class="emoji" data-emoji="1f32d"><i class="em em-hotdog"></i></li>
        <li class="emoji" data-emoji="1f35f"><i class="em em-fries"></i></li>
        <li class="emoji" data-emoji="1f382"><i class="em em-cake"></i></li>

        <!-- Animal Emojis -->
        <li class="emoji" data-emoji="1f436"><i class="em em-dog"></i></li>
        <li class="emoji" data-emoji="1f431"><i class="em em-cat"></i></li>
        <li class="emoji" data-emoji="1f430"><i class="em em-rabbit"></i></li>
        <li class="emoji" data-emoji="1f43c"><i class="em em-panda_face"></i></li>
        <li class="emoji" data-emoji="1f42f"><i class="em em-tiger"></i></li>
        <li class="emoji" data-emoji="1f43b"><i class="em em-bear"></i></li>
        <li class="emoji" data-emoji="1f418"><i class="em em-elephant"></i></li>
        <li class="emoji" data-emoji="1f428"><i class="em em-koala"></i></li>
        <li class="emoji" data-emoji="1f435"><i class="em em-monkey"></i></li>
        <li class="emoji" data-emoji="1f984"><i class="em em-unicorn_face"></i></li>

        <!-- Additional Emojis -->
        <li class="emoji" data-emoji="2615"><i class="em em-coffee"></i></li>
        <li class="emoji" data-emoji="1f37a"><i class="em em-beer"></i></li>
        <li class="emoji" data-emoji="1f680"><i class="em em-rocket"></i></li>
        <li class="emoji" data-emoji="1f525"><i class="em em-fire"></i></li>
    </ul>

</div>