-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: liebman.iad1-mysql-e2-4b.dreamhost.com
-- Generation Time: Jul 05, 2023 at 09:40 AM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inscripchat`
--

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '0=unread,1=read'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `sender_id`, `receiver_id`, `message`, `timestamp`, `status`) VALUES
(135, 32, 29, 'hi', '2023-07-05 08:00:31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

CREATE TABLE `comment_likes` (
  `comment_id` int NOT NULL,
  `user_id` int NOT NULL,
  `like_dislike` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment_likes`
--

INSERT INTO `comment_likes` (`comment_id`, `user_id`, `like_dislike`) VALUES
(64, 29, 1),
(66, 29, 1),
(71, 29, 1);

-- --------------------------------------------------------

--
-- Table structure for table `comment_replies`
--

CREATE TABLE `comment_replies` (
  `id` int NOT NULL,
  `comment_id` int NOT NULL,
  `user_id` int NOT NULL,
  `reply` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment_replies`
--

INSERT INTO `comment_replies` (`id`, `comment_id`, `user_id`, `reply`, `created_at`, `updated_at`) VALUES
(69, 65, 29, 'Reply test', '2023-06-30 05:39:54', '2023-06-30 05:39:54'),
(70, 70, 29, '????', '2023-07-01 06:55:45', '2023-07-01 06:55:45'),
(71, 69, 29, '????', '2023-07-01 06:56:25', '2023-07-01 06:56:25'),
(72, 67, 29, 'reply ????', '2023-07-01 06:58:24', '2023-07-01 06:58:24'),
(73, 65, 29, 'reply 2', '2023-07-01 07:01:15', '2023-07-01 07:01:15'),
(74, 71, 29, '????', '2023-07-01 07:02:51', '2023-07-01 07:02:51'),
(75, 72, 29, '????', '2023-07-01 07:04:51', '2023-07-01 07:04:51'),
(76, 72, 29, '@admin ????', '2023-07-01 07:04:59', '2023-07-01 07:04:59'),
(77, 73, 29, 'reply 1 ????', '2023-07-01 07:07:13', '2023-07-01 07:07:13'),
(78, 73, 29, '@admin sub repl 1 ????', '2023-07-01 07:07:22', '2023-07-01 07:07:22'),
(79, 71, 29, '????', '2023-07-01 07:09:00', '2023-07-01 07:09:00'),
(82, 71, 29, 'reply 1', '2023-07-01 07:13:13', '2023-07-01 07:13:13'),
(83, 71, 29, '????', '2023-07-01 07:13:21', '2023-07-01 07:13:21'),
(84, 71, 29, '@admin sub reply 1', '2023-07-01 07:13:37', '2023-07-01 07:13:37'),
(85, 75, 29, 'reply 1????', '2023-07-01 07:17:43', '2023-07-01 07:17:43'),
(86, 75, 29, '@admin sub reply 1 ????', '2023-07-01 07:18:02', '2023-07-01 07:18:02'),
(87, 71, 29, '@admin new', '2023-07-01 07:23:12', '2023-07-01 07:23:12'),
(88, 71, 29, '@admin new reply', '2023-07-01 07:24:17', '2023-07-01 07:24:17'),
(89, 71, 29, '@admin ????', '2023-07-01 07:26:21', '2023-07-01 07:26:21'),
(90, 71, 29, '@admin ????', '2023-07-01 07:27:55', '2023-07-01 07:27:55'),
(91, 71, 29, '@admin ????', '2023-07-01 07:29:00', '2023-07-01 07:29:00'),
(92, 71, 29, '@admin ????', '2023-07-01 07:29:52', '2023-07-01 07:29:52'),
(93, 76, 29, 'ok ????', '2023-07-02 04:25:42', '2023-07-02 04:25:42'),
(94, 76, 29, '😁', '2023-07-02 04:27:45', '2023-07-02 04:27:45'),
(95, 71, 29, '😂', '2023-07-04 01:16:48', '2023-07-04 01:16:48'),
(96, 71, 29, '❤️', '2023-07-04 01:17:47', '2023-07-04 01:17:47'),
(97, 71, 29, '@admin😘 ', '2023-07-04 01:27:00', '2023-07-04 01:27:00'),
(98, 84, 29, '😢', '2023-07-05 00:00:33', '2023-07-05 00:00:33'),
(99, 84, 29, '@admin 😫', '2023-07-05 00:00:46', '2023-07-05 00:00:46'),
(100, 86, 29, '🙂', '2023-07-05 08:21:02', '2023-07-05 08:21:02'),
(101, 86, 29, '@admin 😍', '2023-07-05 08:21:19', '2023-07-05 08:21:19'),
(102, 71, 29, '@admin hi', '2023-07-05 08:21:48', '2023-07-05 08:21:48'),
(103, 86, 29, '@admin 😭', '2023-07-05 08:23:19', '2023-07-05 08:23:19'),
(104, 86, 29, 'hi', '2023-07-05 08:25:34', '2023-07-05 08:25:34'),
(105, 86, 29, '@admin hello', '2023-07-05 08:25:39', '2023-07-05 08:25:39');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int NOT NULL,
  `name` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`) VALUES
(1, 'Computer Science'),
(2, 'Chemistry'),
(3, 'Physics'),
(5, 'Economics');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `friend_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id`, `user_id`, `friend_id`, `created_at`, `updated_at`) VALUES
(94, 29, 32, '2023-07-02 13:07:09', '2023-07-02 13:07:09');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int NOT NULL,
  `owner_id` int NOT NULL,
  `name` text COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `owner_id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(30, 29, 'Group 1', NULL, '2023-07-02 04:50:21', '2023-07-02 04:50:21'),
(31, 29, 'Group 2', NULL, '2023-07-02 06:07:35', '2023-07-02 06:07:35');

-- --------------------------------------------------------

--
-- Table structure for table `group_members`
--

CREATE TABLE `group_members` (
  `group_id` int NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_members`
--

INSERT INTO `group_members` (`group_id`, `user_id`) VALUES
(31, 32);

-- --------------------------------------------------------

--
-- Table structure for table `online_users`
--

CREATE TABLE `online_users` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `online_users`
--

INSERT INTO `online_users` (`id`, `user_id`, `last_activity`) VALUES
(4589, 29, '2023-07-05 16:33:23');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int NOT NULL,
  `author_id` int NOT NULL,
  `group_id` int NOT NULL DEFAULT '0',
  `title` text COLLATE utf8mb4_general_ci,
  `content` text COLLATE utf8mb4_general_ci,
  `type` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tags` text COLLATE utf8mb4_general_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `author_id`, `group_id`, `title`, `content`, `type`, `tags`, `created_at`, `updated_at`) VALUES
(37, 29, 0, 'Lectures 1-7 Supply and Demand. Consumer Theory', '6498858c73e9e-Lectures 1-7 Supply and Demand. Consumer Theory.pdf', 'pdf', 'Economics, Principles Of Microeconomics, Supply and Demand. Consumer Theory, ', '2023-06-25 11:21:26', '2023-06-25 11:21:26'),
(41, 29, 0, 'Lecture 2 The Balance Sheet and the Recording of Transactions', '6498aad6bd36d-Lecture 2 The Balance Sheet and the Recording of Transactions.pdf', 'pdf', 'Accounting, The Balance Sheet, Recording of Transactions', '2023-06-25 14:00:09', '2023-06-25 14:00:09'),
(42, 29, 0, 'Accounting Exam 1', '6498ac677ec5c-Exam 1.pdf', 'pdf', 'Accounting, Inventory accounting', '2023-06-25 14:07:11', '2023-06-25 14:07:11'),
(44, 29, 0, 'Demo video 1', '649a64377183e-file_example_MP4_480_1_5MG.mp4', 'video', 'umw', '2023-06-26 21:23:25', '2023-06-26 21:23:25'),
(45, 29, 0, 'Demo pdf 1', '649ad194ea89f-Get_Started_With_Smallpdf.pdf', 'pdf', 'umw', '2023-06-27 05:10:06', '2023-06-27 05:10:06'),
(46, 29, 0, 'Demo image 1', '649e6ee24ddf8-1.jfif', 'image', 'umw', '2023-06-29 22:58:02', '2023-06-29 22:58:02'),
(47, 29, 0, 'Demo video 2', '649e70df2dde5-file_example_MP4_480_1_5MG.mp4', 'video', 'umw', '2023-06-29 23:06:27', '2023-06-29 23:06:27'),
(48, 29, 0, 'What is the Computer Science', '64a167f3801d2-What Is Computer Science-.mp4', 'video', 'Computer Science, Technology, IT, ', '2023-07-02 05:06:21', '2023-07-02 05:06:21'),
(49, 29, 30, 'Hello', '64a589268cf0c9.51279908.png', 'image', 'Undergraduate,UMW,Computer Science', '2023-07-05 08:15:50', '2023-07-05 08:15:50'),
(50, 32, 31, NULL, 'Hello', 'text', 'Undergraduate,UMW,Computer Science', '2023-07-05 09:26:55', '2023-07-05 09:26:55');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE `post_comments` (
  `id` int NOT NULL,
  `post_id` int NOT NULL,
  `user_id` int NOT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`id`, `post_id`, `user_id`, `comment`, `created_at`, `updated_at`) VALUES
(64, 47, 29, 'New comment', '2023-06-30 04:34:26', '2023-06-30 04:34:26'),
(65, 45, 29, 'Test', '2023-06-30 05:29:51', '2023-06-30 05:29:51'),
(66, 47, 29, 'comment working', '2023-06-30 17:06:20', '2023-06-30 17:06:20'),
(67, 45, 29, 'new comment', '2023-07-01 06:51:08', '2023-07-01 06:51:08'),
(68, 45, 29, 'comment 3', '2023-07-01 06:53:33', '2023-07-01 06:53:33'),
(69, 45, 29, 'comment 4', '2023-07-01 06:53:49', '2023-07-01 06:53:49'),
(70, 45, 29, 'comment 5', '2023-07-01 06:55:37', '2023-07-01 06:55:37'),
(71, 46, 29, 'comment 1', '2023-07-01 07:02:44', '2023-07-01 07:02:44'),
(72, 46, 29, 'comment 2', '2023-07-01 07:04:24', '2023-07-01 07:04:24'),
(73, 46, 29, 'comment 3', '2023-07-01 07:07:03', '2023-07-01 07:07:03'),
(75, 46, 29, 'comment 3', '2023-07-01 07:17:32', '2023-07-01 07:17:32'),
(76, 45, 29, 'lets test again', '2023-07-01 13:42:43', '2023-07-01 13:42:43'),
(77, 48, 29, 'THIS VIDEO S NOT BAD✌', '2023-07-02 05:10:25', '2023-07-02 05:10:25'),
(78, 46, 29, 'test emoji 1 😃 emoji 2 💕', '2023-07-04 22:33:46', '2023-07-04 22:33:46'),
(79, 46, 29, 'test emoji 1 😃 emoji 2 💕', '2023-07-04 22:33:52', '2023-07-04 22:33:52'),
(80, 46, 29, '❤', '2023-07-04 22:39:29', '2023-07-04 22:39:29'),
(81, 46, 29, '😠', '2023-07-04 23:50:32', '2023-07-04 23:50:32'),
(82, 46, 29, '💔 no', '2023-07-04 23:53:08', '2023-07-04 23:53:08'),
(83, 46, 29, 'new comment', '2023-07-04 23:58:39', '2023-07-04 23:58:39'),
(84, 46, 29, 'comment test emoji', '2023-07-04 23:59:51', '2023-07-04 23:59:51'),
(85, 48, 29, 'Is Computer Science cool', '2023-07-05 01:18:26', '2023-07-05 01:18:26'),
(86, 49, 29, 'Nice 😍', '2023-07-05 08:20:48', '2023-07-05 08:20:48'),
(87, 50, 32, 'new comment', '2023-07-05 09:27:04', '2023-07-05 09:27:04'),
(88, 42, 29, 'hello', '2023-07-05 09:30:49', '2023-07-05 09:30:49');

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `post_id` int NOT NULL,
  `user_id` int NOT NULL,
  `like_dislike` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`post_id`, `user_id`, `like_dislike`) VALUES
(46, 29, 1),
(45, 29, 1),
(47, 29, 0);

-- --------------------------------------------------------

--
-- Table structure for table `post_views`
--

CREATE TABLE `post_views` (
  `post_id` int NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_views`
--

INSERT INTO `post_views` (`post_id`, `user_id`) VALUES
(37, 29),
(46, 29),
(45, 29),
(47, 29),
(48, 29),
(48, 33),
(48, 34);

-- --------------------------------------------------------

--
-- Table structure for table `reply_likes`
--

CREATE TABLE `reply_likes` (
  `reply_id` int NOT NULL,
  `user_id` int NOT NULL,
  `like_dislike` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reply_likes`
--

INSERT INTO `reply_likes` (`reply_id`, `user_id`, `like_dislike`) VALUES
(74, 29, 0),
(79, 29, 1),
(87, 29, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `img` text COLLATE utf8mb4_general_ci,
  `course` int NOT NULL,
  `qualification` tinyint NOT NULL DEFAULT '0' COMMENT '0=undergraduate\r\n1=postgraduate',
  `institution` text COLLATE utf8mb4_general_ci,
  `is_admin` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '0=deleted,1=active',
  `confirmation_token` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `is_confirmed` int NOT NULL DEFAULT '0',
  `pass_token` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `img`, `course`, `qualification`, `institution`, `is_admin`, `created_at`, `status`, `confirmation_token`, `is_confirmed`, `pass_token`) VALUES
(29, 'Admin', 'admin', 'admin@inscripchat.com', '$2y$10$bwT90L/DEJukOekFGF1tr.wb136L9IGeNXonFpsQZ7gvcrNjEQ/NG', '649ad47ca1fba-male.webp', 1, 0, 'UMW', 1, '2023-06-24 23:46:36', 0, NULL, 1, NULL),
(32, 'Muhammad Awais', 'awais', 'hyipsgroup2025@gmail.com', '$2y$10$zS2MQMUlOMlCmwP759SmLei66LYC6yWufuaUrbPJLTl/IQdIJbqvW', '649ec0ee6caf8-328490371_1229626440974655_8927849870074007970_n.jpg', 1, 0, 'UMW', 0, '2023-06-30 04:47:58', 1, NULL, 1, NULL),
(33, 'Mfundo', 'The Veteran', 'mfundoepsilon@gmail.com', '$2y$10$WXMtKelmymeet.2Xjz.MXukcAioHDeHEPq10A6aneMpTGCM8XKZk.', '64a47dde228a0-019.jpg', 1, 0, 'University of Cape Town', 0, '2023-07-04 13:15:26', 1, NULL, 1, NULL),
(34, 'Basetsana', 'BasiK', 'bmasenya@gmail.com', '$2y$10$rwjPF3d4M/qOrBO.a5q6y.n3KYU4K4gp.NfMIEJH8LSqNCxCurPzy', '64a47fe6e6029-020.jpg', 1, 0, 'University of Cape Town', 0, '2023-07-04 13:24:06', 1, NULL, 1, NULL),
(35, 'Inscrip', 'Inscripchat', 'inscripchat@gmail.com', '$2y$10$XvGrmfK0zTIpUNvSfuHlw.JNO6BqcQKt5epEfagsRebsVqNhwy6RW', '64a486bd31591-035.jpg', 1, 1, 'University of Cape Town', 0, '2023-07-04 13:53:17', 1, NULL, 1, NULL),
(39, 'Muhammad Awais', 'awais2', 'umwdeveloper@gmail.com', '$2y$10$oc6O04JVVwFlRTzeVDEU7eR40htHPqB.zuG9TjjFAfsyjo198P9Su', '64a4f01678e80-331577628_577102737808874_7394004400096513061_n.jpg', 1, 0, 'UMW', 0, '2023-07-04 21:22:46', 1, NULL, 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD KEY `comment_like_fk` (`comment_id`),
  ADD KEY `user_comment_like_fk` (`user_id`);

--
-- Indexes for table `comment_replies`
--
ALTER TABLE `comment_replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comment_replies_comment_fk` (`comment_id`),
  ADD KEY `comment_replies_user_fk` (`user_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`),
  ADD KEY `friends_ibfk_1` (`user_id`),
  ADD KEY `friends_ibfk_2` (`friend_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_owner_fk` (`owner_id`);

--
-- Indexes for table `group_members`
--
ALTER TABLE `group_members`
  ADD KEY `group_group_members_fk` (`group_id`),
  ADD KEY `user_group_members_fk` (`user_id`);

--
-- Indexes for table `online_users`
--
ALTER TABLE `online_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_post_fk` (`author_id`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_comments_post_fk` (`post_id`),
  ADD KEY `post_comments_user_fk` (`user_id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD KEY `post_like_fk` (`post_id`),
  ADD KEY `user_post_like_fk` (`user_id`);

--
-- Indexes for table `post_views`
--
ALTER TABLE `post_views`
  ADD KEY `post_views_user_fk` (`user_id`),
  ADD KEY `post_views_post_fk` (`post_id`);

--
-- Indexes for table `reply_likes`
--
ALTER TABLE `reply_likes`
  ADD KEY `reply_like_fk` (`reply_id`),
  ADD KEY `user_reply_like_fk` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_user_fk` (`course`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `comment_replies`
--
ALTER TABLE `comment_replies`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `online_users`
--
ALTER TABLE `online_users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4608;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chats`
--
ALTER TABLE `chats`
  ADD CONSTRAINT `chats_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chats_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD CONSTRAINT `comment_like_fk` FOREIGN KEY (`comment_id`) REFERENCES `post_comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_comment_like_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comment_replies`
--
ALTER TABLE `comment_replies`
  ADD CONSTRAINT `comment_replies_comment_fk` FOREIGN KEY (`comment_id`) REFERENCES `post_comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comment_replies_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `friends`
--
ALTER TABLE `friends`
  ADD CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`friend_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `group_owner_fk` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `group_members`
--
ALTER TABLE `group_members`
  ADD CONSTRAINT `group_group_members_fk` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_group_members_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `user_post_fk` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD CONSTRAINT `post_comments_post_fk` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_comments_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_like_fk` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_post_like_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_views`
--
ALTER TABLE `post_views`
  ADD CONSTRAINT `post_views_post_fk` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_views_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reply_likes`
--
ALTER TABLE `reply_likes`
  ADD CONSTRAINT `reply_like_fk` FOREIGN KEY (`reply_id`) REFERENCES `comment_replies` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_reply_like_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `course_user_fk` FOREIGN KEY (`course`) REFERENCES `courses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
