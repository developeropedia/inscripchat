<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', '');
  define('DB_NAME', 'inscripchat');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/inscripchat');
  // Site Name
  define('SITENAME', 'InscripChat');

  // PHPMailer
  define("SMTP_HOST", "smtp.dreamhost.com");
  define("SMTP_PORT", "465");
  define("SMTP_USERNAME", "support@inscripchat.com");
  define("SMTP_PASSWORD", "sqesUB4?");
  define("SMTP_NAME", "Inscripchat");